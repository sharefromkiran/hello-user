package com.kiran.hello_user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
