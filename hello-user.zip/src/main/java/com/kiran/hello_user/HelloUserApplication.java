package com.kiran.hello_user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloUserApplication.class, args);
	}

}
